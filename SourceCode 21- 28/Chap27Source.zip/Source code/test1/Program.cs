﻿using System;

namespace test1
{
    class Program
    {
        // Write 'value' as a human-readable string to the output buffer.
        void WriteInt32ToBuffer(int value, Buffer buffer);

        // Display the contents of the buffer to the console.
        void DisplayBufferToConsole(Buffer buffer);

        // Application code
        static void Main()
        {
            var buffer = CreateBuffer();
            try
            {
                int value = Int32.Parse(Console.ReadLine());
                WriteInt32ToBuffer(value, buffer);
                DisplayBufferToConsole(buffer);
            }
            finally
            {
                buffer.Destroy();
            }
        }

        private static Memory<Char> CreateBuffer()
        {
            throw new NotImplementedException();
        }
    }
}


