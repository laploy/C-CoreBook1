﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace test6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
        static void Log1(ReadOnlyMemory<char> message)
        {
            Task.Run(() =>
            {
                StreamWriter sw = File.AppendText(@".\input-numbers.dat");
                sw.WriteLine(message);
            });
        }
        static Task Log2(ReadOnlyMemory<char> message)
        {
            return Task.Run(() => {
                StreamWriter sw = File.AppendText(@".\input-numbers.dat");
                sw.WriteLine(message);
                sw.Flush();
            });
        }
        static void Log3(ReadOnlyMemory<char> message)
        {
            string defensiveCopy = message.ToString();
            Task.Run(() => {
                StreamWriter sw = File.AppendText(@".\input-numbers.dat");
                sw.WriteLine(defensiveCopy);
                sw.Flush();
            });
        }
        static void Log4(ReadOnlyMemory<char> message)
        {
            Task.Run(() => {
                string defensiveCopy = message.ToString();
                StreamWriter sw = File.AppendText(@".\input-numbers.dat");
                sw.WriteLine(defensiveCopy);
                sw.Flush();
            });
        }
    }
}


