﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Fred";
            String.Format("Name = {0}, hours = {1:hh}", name, DateTime.Now);

            string primes;
            primes = String.Format("Prime numbers less than 10: {0}, {1}, {2}, {3}",
                                   2, 3, 5, 7);
            Console.WriteLine(primes);

            string multiple = String.Format("0x{0:X} {0:E} {0:N}",
                                Int64.MaxValue);
            Console.WriteLine(multiple);

            string[] names = { "Adam", "Bridgette", "Carla", "Daniel",
                         "Ebenezer", "Francine", "George" };
            decimal[] hours = { 40, 6.667m, 40.39m, 82, 40.333m, 80,
                                 16.75m };

            Console.WriteLine("{0,-20} {1,5}\n", "Name", "Hours");
            for (int ctr = 0; ctr < names.Length; ctr++)
                Console.WriteLine("{0,-20} {1,5:N1}", names[ctr], hours[ctr]);

            int value = 6324;
            string output = string.Format("{0}{1:D}{2}",
                                         "{", value, "}");
            Console.WriteLine(output);
        }
    }
}



