

public static void Demo()
{
	var letters = ("a", "b");

	var named = (first: "one", second: "two");
}

public static void Demo()
{
    var count = 5;
    var type = "Orange";
 
    var tuple = (Count: count, Type: type);
}

public static void Demo()
{
    var count = 5;
    var type = "Orange";
	var stringContent = "The answer to everything";
 
    var tuple = (count, type);
	var mixedTuple = (42, stringContent);
}


