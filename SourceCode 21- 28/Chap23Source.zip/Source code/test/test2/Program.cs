﻿using System;

namespace test2
{
    class Program
    {
        private static readonly Point1 origin = new Point1(0, 0);
        public static ref readonly Point1 Origin => ref origin;
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }

    public readonly struct Point1
    {
        public double X { get; }
        public double Y { get; }

        public Point1(double x, double y) => (X, Y) = (x, y);

        public override string ToString() => $"({X}, {Y})";
    }

    public readonly struct Point2
    {
        public readonly double X;
        public readonly double Y;

        public Point2(double x, double y) => (X, Y) = (x, y);

        public override string ToString() => $"({X}, {Y})";
    }
}

