﻿using System;

namespace test4
{
    public struct Point1
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Distance => Math.Sqrt(X * X + Y * Y);

        public override string ToString() =>
            $"({X}, {Y}) is {Distance} from the origin";
    }

    class Program
    {
        public static Point1 Change(Point1 p)
        {
            p.X = 13;
            p.Y = 13;
            return p;
        }

        static void Main(string[] args)
        {
            Point1 myP1 = new Point1();
            myP1.X = 10;
            myP1.Y = 20;
            Console.WriteLine("myP1 " + myP1.ToString());
            Console.WriteLine("- - - - - - - - - - - - - - - - ");

            Point1 myP1a = new Point1();
            myP1a.X = 11;
            myP1a.Y = 21;
            Console.WriteLine("myP1 " + myP1.ToString());
            Console.WriteLine("myP1a " + myP1a.ToString());
            Console.WriteLine("- - - - - - - - - - - - - - - - ");

            Point1 myP1b = myP1a;
            myP1b.X = 12;
            myP1b.Y = 22;
            Console.WriteLine("myP1 " + myP1.ToString());
            Console.WriteLine("myP1a " + myP1a.ToString());
            Console.WriteLine("myP1b " + myP1b.ToString());
            Console.WriteLine("- - - - - - - - - - - - - - - - ");

            Point1 x = Change(myP1);
            Console.WriteLine("myP1 " + myP1.ToString());
            Console.WriteLine("x " + x.ToString());
        }
    }
}
