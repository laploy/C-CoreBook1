﻿using System;
using System.Collections.Generic;
using System.Text;

namespace test1
{
    class Age
    {
        readonly int year;
        Age(int year)
        {
            this.year = year;
        }
        void ChangeYear()
        {
            year = 1967; // Compile error if uncommented.
        }
    }
}


