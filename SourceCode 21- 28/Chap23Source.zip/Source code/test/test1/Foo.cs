﻿using System;
using System.Collections.Generic;
using System.Text;

namespace test1
{
    class Foo
    {
        readonly int i;
        public Foo()
        {
            i = 11;
            Console.WriteLine(i);
        }
    }

    class Foo2
    {
        static int i = 11;
        public static void disp()
        {
            Console.WriteLine(i);
        }
    }

    class Foo3
    {
        int i = 9;
        public static void disp()
        {
            Console.WriteLine(i);
        }
    }
}


