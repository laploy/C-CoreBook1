﻿using System;

namespace test1
{
    class Program
    {
        const int ab = 123;
        const string s1 = "Hello";

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

        void Sum(int j)
        {
            const int i = 9, k = 2;
            const int A = i + k;
        }

        void Sum2(int j)
        {
            const int i = 9, k = 2;
            // const int A = i + k;  
            const int B = i + j;
        }
    }
}


