﻿using System;
using System.Text.RegularExpressions;

namespace Applications.ConsoleApps
{
    public class ConsoleParser
    {
        public static void Main()
        {
            Console.WriteLine("Enter any text, followed by <Enter>:\n");
            String s = Console.ReadLine();
            ShowWords(s);
            Console.Write("\nPress any key to continue... ");
            Console.ReadKey();
        }

        private static void ShowWords(String s)
        {
            String pattern = @"\w+";
            var matches = Regex.Matches(s, pattern);
            if (matches.Count == 0)
            {
                Console.WriteLine("\nNo words were identified in your input.");
            }
            else
            {
                Console.WriteLine($"\nThere are {matches.Count} words in your string:");
                for (int ctr = 0; ctr < matches.Count; ctr++)
                {
                    Console.WriteLine($"   #{ctr,2}: '{matches[ctr].Value}' at position " +
                        $"{matches[ctr].Index}");
                }
            }
        }
    }
}

/*
Enter any text, followed by <Enter>:

Alice is playing with a white kitten 
(whom she calls "Snowdrop") and a black kitten 
(whom she calls "Kitty") when she ponders what 
the world is like on the other side of a 
mirror's reflection.

There are 36 words in your string:
   # 0: 'Alice' at position 0
   # 1: 'is' at position 6
   # 2: 'playing' at position 9
   # 3: 'with' at position 17
   # 4: 'a' at position 22
   # 5: 'white' at position 24
   # 6: 'kitten' at position 30
   # 7: 'whom' at position 38
   # 8: 'she' at position 43
   # 9: 'calls' at position 47
   #10: 'Snowdrop' at position 54
   #11: 'and' at position 65
   #12: 'a' at position 69
   #13: 'black' at position 71
   #14: 'kitten' at position 77
   #15: 'whom' at position 85
   #16: 'she' at position 90
   #17: 'calls' at position 94
   #18: 'Kitty' at position 101
   #19: 'when' at position 109
   #20: 'she' at position 114
   #21: 'ponders' at position 118
   #22: 'what' at position 126
   #23: 'the' at position 131
   #24: 'world' at position 135
   #25: 'is' at position 141
   #26: 'like' at position 144
   #27: 'on' at position 149
   #28: 'the' at position 152
   #29: 'other' at position 156
   #30: 'side' at position 162
   #31: 'of' at position 167
   #32: 'a' at position 170
   #33: 'mirror' at position 172
   #34: 's' at position 179
   #35: 'reflection' at position 181

Press any key to continue...
 */
