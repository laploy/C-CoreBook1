﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace test5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        void Foo()
        {
            using (var font1 = new Font("Arial", 10.0f))
            {
                byte charset1 = font1.GdiCharSet;
            }
            // Beginning with C# 8.0
            using var font2 = new Font("Arial", 10.0f);
            byte charset2 = font2.GdiCharSet;

            // The using statement ensures that Dispose is called
            {
                var font3 = new Font("Arial", 10.0f);
                try
                {
                    byte charset3 = font3.GdiCharSet;
                }
                finally
                {
                    if (font3 != null)
                        ((IDisposable)font3).Dispose();
                }
            }

            // Multiple instances of a type can be declared
            using (Font font4 = new Font("Arial", 10.0f),
                        font5 = new Font("Arial", 10.0f))
            {
                // Use font4 and font5
            }

            // C# 8.0 Multiple instances syntax
            using Font font6 = new Font("Arial", 10.0f),
                       font7 = new Font("Arial", 10.0f);
            // Use font6 and font7.

            var font8 = new Font("Arial", 10.0f);
            using (font8) // not recommended
            {
                // use font8
            }
            // font8 is still in scope
            // but the method call throws an exception
            float f = font8.GetHeight();
        }

    }
}





