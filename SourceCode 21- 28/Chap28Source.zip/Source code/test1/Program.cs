﻿using System;
using System.Collections.Generic;

namespace test1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] s = new string[4];
            s[0] = "One thing was certain.";
            s[1] = "the white kitten had nothing.";
            s[2] = "it was the black kitten’s fault.";
            s[3] = "the white kitten had Second toy.";
            WriteLinesToFile(s);
            Console.WriteLine("End program.");
        }
        static int WriteLinesToFile(IEnumerable<string> lines)
        {
            using var file = new 
                System.IO.StreamWriter("WriteLines2.txt");
            // Notice how we declare skippedLines 
            // after the using statement.
            int skippedLines = 0;
            foreach (string line in lines)
            {
                if (!line.Contains("Second"))
                {
                    file.WriteLine(line);
                }
                else
                {
                    skippedLines++;
                }
            }
            // Notice how skippedLines is in scope here.
            return skippedLines;
            // file is disposed here
        }
    }
}



