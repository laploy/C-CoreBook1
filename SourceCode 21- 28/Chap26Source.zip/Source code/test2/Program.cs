﻿using System;

namespace test2
{
    class Program
    {
        private static ReadOnlySpan<char>
            TrimStart(ReadOnlySpan<char> text)
        {
            if (text.IsEmpty)
            {
                return text;
            }

            int i = 0;
            char c;

            while ((c = text[i]) == ' ')
            {
                i++;
            }

            return text.Slice(i);
        }
        static void Main(string[] args)
        {
            string text = "  I am up to no good.";
            Console.WriteLine(TrimStart(text).ToArray());
        }
    }
}



