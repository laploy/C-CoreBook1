﻿using System;
using System.ComponentModel;

namespace test
{
    public ref struct MyRefStruct
    {
        public int MyIntValue1;
        public int MyIntValue2;

        [EditorBrowsable(EditorBrowsableState.Never)]
        public override bool Equals(object obj) => 
            throw new NotSupportedException();

        [EditorBrowsable(EditorBrowsableState.Never)]
        public override int GetHashCode() => 
            throw new NotSupportedException();

        [EditorBrowsable(EditorBrowsableState.Never)]
        public override string ToString() => 
            throw new NotSupportedException();
    }

    public readonly ref struct StudentStruct
    {
        public readonly int StudentId;
        public readonly int Score;

        public StudentStruct(int value1, int value2)
        {
            this.StudentId = value1;
            this.Score = value2;
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        public override bool Equals(object obj) => throw new NotSupportedException();

        [EditorBrowsable(EditorBrowsableState.Never)]
        public override int GetHashCode() => throw new NotSupportedException();

        [EditorBrowsable(EditorBrowsableState.Never)]
        public override string ToString() => throw new NotSupportedException();
    }

    class test
    {
        static void Main2(string[] args)
        {
            StudentStruct s = new StudentStruct(123, 456);
            //s.StudentId = 2;
            Console.WriteLine(s.StudentId);
        }
        //private static StudentStruct hello { get; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            MyRefStruct s = default;
            s.MyIntValue1 = 2;
            Console.WriteLine(s.MyIntValue1);
        }
        //private static MyRefStruct hello { get;  }
    }
}




