﻿using System;
using System.Runtime.InteropServices;

namespace test6
{
    class Program
    {
        static void Main(string[] args)
        {
            var array = new byte[100];
            var arraySpan = new Span<byte>(array);
            InitializeSpan(arraySpan);
            Console.WriteLine($"The sum is {ComputeSum(arraySpan):N0}");
            var native = Marshal.AllocHGlobal(100);
            Span<byte> nativeSpan;
            unsafe
            {
                nativeSpan = new Span<byte>(native.ToPointer(), 100);
            }
            InitializeSpan(nativeSpan);
            Console.WriteLine($"The sum is {ComputeSum(nativeSpan):N0}");
            Marshal.FreeHGlobal(native);
            Span<byte> stackSpan = stackalloc byte[100];
            InitializeSpan(stackSpan);
            Console.WriteLine($"The sum is {ComputeSum(stackSpan):N0}");
        }
        public static void InitializeSpan(Span<byte> span)
        {
            byte value = 0;
            for (int ctr = 0; ctr < span.Length; ctr++)
                span[ctr] = value++;
        }
        public static int ComputeSum(Span<byte> span)
        {
            int sum = 0;
            foreach (var value in span)
                sum += value;

            return sum;
        }
    }
}


