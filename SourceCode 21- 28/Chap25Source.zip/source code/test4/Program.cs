﻿using System;

namespace test4
{
    class Program
    {
        static void Main(string[] args)
        {
            string ชื่อนักเรียน = "ลาภลอย วานิชอังกูร";
            int อายุ = 12;
            แสดงข้อมูลนักเรียน(ชื่อนักเรียน, อายุ);
        }
        static void แสดงข้อมูลนักเรียน(string ชื่อนักเรียน, int อายุ)
        {
            Console.WriteLine($"ชื่อนักเรียน: {ชื่อนักเรียน}");
            Console.WriteLine($"อายุ: {อายุ}");
        }
    }
}


