﻿using System;

namespace test3
{
    class Program
    {
        static void Main(string[] args)
        {
            Span<int> numbers = 
                stackalloc[] { 1, 2, 3, 4, 5, 6 };

            var ind = numbers.IndexOfAny(
                stackalloc[] { 2, 4, 6, 8 });

            Console.WriteLine(ind);  // output: 1

            unsafe
            {
                int length = 3;
                int* numbers2 = stackalloc int[length];
                for (var i = 0; i < length; i++)
                {
                    numbers2[i] = i;
                }
            }

            Span<int> first = 
                stackalloc int[3] { 1, 2, 3 };

            Span<int> second = 
                stackalloc int[] { 1, 2, 3 };

            ReadOnlySpan<int> third = 
                stackalloc[] { 1, 2, 3 };
        }
    }
}


