﻿using System;

namespace test2
{
    class Program
    {
        static void Main(string[] args)
        {
            int length = 3;
            Span<int> numbers = stackalloc int[length];
            for (var i = 0; i < length; i++)
            {
                numbers[i] = i;
            }

            int length2 = 1000;
            Span<byte> buffer = 
                length2 <= 1024 ? 
                    stackalloc byte[length2] : 
                    new byte[length2];
        }
    }
}


