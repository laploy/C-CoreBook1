﻿using System;
using ExtensionMethods;
using System.Linq;

namespace ExtensionMethods
{
    public static class MyExtensions
    {
        public static int WordCount(this String str)
        {
            return str.Split(new char[] { ' ', '.', '?' },
                             StringSplitOptions.RemoveEmptyEntries).Length;
        }

        public static void test()
        {
            string s = "Hello Extension Methods";
            int i = s.WordCount();
        }
    }
}




