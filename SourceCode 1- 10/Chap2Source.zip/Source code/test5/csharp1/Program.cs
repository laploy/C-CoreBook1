﻿using System;

namespace csharp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = Util.id;
            int b = Util.add(20, 30);
            Console.WriteLine("End.");
        }
    }
}

public static class Util
{
    public static int id = 123;

    public static int add(int a, int b)
    {
        return a + b;
    }
}


