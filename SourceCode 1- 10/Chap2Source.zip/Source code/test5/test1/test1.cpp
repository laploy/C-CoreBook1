int i = 123;

int add(int a, int b) {
	return a + b;
}

class Foo {
	int b = i + 1;
	int c = add(20, 30);
};

int main()
{
	return 0;
}



