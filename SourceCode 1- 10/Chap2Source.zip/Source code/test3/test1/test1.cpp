#include <iostream>
using namespace std;

int f(int);
class Vector;

class Matrix {
	int a = f(2);
	friend Vector operator*(const Matrix&, const Vector&);
};

class Vector {
	friend Vector operator*(const Matrix&, const Vector&);
};

int f(int x)
{
	return ++x;
}

int main()
{
	return 0;
}



