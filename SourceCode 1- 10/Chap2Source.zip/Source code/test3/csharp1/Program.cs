﻿using System;

namespace csharp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("End.");
        }
        class Matrix
        {
            int a = Fun(2);
            Vector v;
            Matrix m;
        };
        class Vector
        {
            Vector v;
            Matrix m;
        };

        static int Fun(int x)
        {
            return ++x;
        }
    }
}


