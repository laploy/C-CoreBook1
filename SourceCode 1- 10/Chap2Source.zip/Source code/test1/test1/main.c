#include <stdio.h>
#include "Header1.h"

int main()
{
	int a = 5;
	printf("%d\n", add(1,2));
	printf("End.");
}