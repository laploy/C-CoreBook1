﻿using System;

namespace csharp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(test1.Add(1, 2));
            Console.WriteLine("End.");
        }
    }
}
