﻿namespace csharp1
{
    public static class test1
    {
        public static int Add(int a, int b)
        {
            return a + b;
        }
    }
}