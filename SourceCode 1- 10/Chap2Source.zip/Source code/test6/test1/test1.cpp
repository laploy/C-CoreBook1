#include <iostream>
using namespace std;


int main()
{
	bool is_a_car = true;
	int salary = 1;

	if (is_a_car)
		cout << "abc" << endl;
	else
		cout << "def" << endl;

	if (salary)
		cout << "ghi" << endl;
	else
		cout << "jkl" << endl;

	return 0;
}


