﻿using System;

namespace csharp1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isACar = true;
            int salary = 1;

            if (isACar)
                Console.WriteLine("abc");
            else
                Console.WriteLine("def");

            if (salary)
                Console.WriteLine("ghi");
            else
                Console.WriteLine("jkl");

            Console.WriteLine("End.");
        }
    }
}

