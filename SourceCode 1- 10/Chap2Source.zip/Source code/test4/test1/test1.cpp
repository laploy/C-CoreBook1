//// file Foo.h
//class Foo{
//	Bar myBar;
//};
//
//// file Bar.h
//class Bar {
//	Foo myFoo;
//};
//
//// file main.cc
//#include "Foo.h"
//#include "Bar.h"
int main()
{
	//Foo f;
	return 0;
}
//


