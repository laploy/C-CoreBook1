﻿using System;

namespace csharp1
{
    class Program
    {
        class Foo
        {
            Bar myBar = new Bar();
        }
        class Bar
        {
            Foo myFoo = new Foo();
        }
        static void Main(string[] args)
        {
            Foo myFoo = new Foo();
            Console.WriteLine("End.");
        }
    }
}


