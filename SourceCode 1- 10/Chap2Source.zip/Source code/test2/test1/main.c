#include <stdio.h>

int add(int a, int b)
{
	return a + b;
}

int main()
{
	int a = 5;
	printf("%d\n", add(1,2));
	printf("%d\n", sub(50, 7));
	printf("End.");
}

int sub(int a, int b)
{
	return a - b;
}


