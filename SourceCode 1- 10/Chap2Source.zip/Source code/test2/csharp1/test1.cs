﻿namespace csharp1
{
    public static class test1
    {

    }
}