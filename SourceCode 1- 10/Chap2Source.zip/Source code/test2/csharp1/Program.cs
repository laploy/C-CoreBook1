﻿using System;

namespace csharp1
{
    class Program
    {
        static int Add(int a, int b)
        {
            return a + b;
        }

        static void Main(string[] args)
        {
            Console.WriteLine(Add(1, 2));
            Console.WriteLine(Add(50, 7));
            Console.WriteLine("End.");
        }

        static int Sub(int a, int b)
        {
            return a - b;
        }
    }
}


