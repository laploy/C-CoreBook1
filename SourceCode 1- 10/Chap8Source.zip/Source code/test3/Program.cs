﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test3
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 1;
            Method(ref number);
            Console.WriteLine(number);
            // Output: 45
        }

        static void Method(ref int refArgument)
        {
            refArgument = refArgument + 44;
        }

    }
}

