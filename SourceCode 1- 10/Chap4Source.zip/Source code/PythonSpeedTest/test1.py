import time

# ---- test for loop
start = time.time()
a = range(100000)
b = []
for i in a:
    b.append(i*2)
end = time.time()
print(end - start)
# result = 0.0199999809265

# test list comprehension
start = time.time()
a = range(100000)
b = [i*2 for i in a]
end = time.time()
print(end - start)
# result = 0.0110001564026

