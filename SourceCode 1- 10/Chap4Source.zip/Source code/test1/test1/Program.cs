﻿using System;

namespace test1
{
    public class foo
    {
        sbyte b;
        char c;
        string s;
        public void test()
        {
            Console.WriteLine(b);
            Console.WriteLine(c);
            Console.WriteLine(s);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            foo myFoo = new foo();
            myFoo.test();
        }
    }
}