
public static return_type operator op (Type t)
{
	// Statements
}

