﻿using System;

namespace test4
{
    class Program
    {
        // Unsafe method: takes pointer to int:
        unsafe static void Foo(int* p)
        {
            *p = *p + 2;
        }
        static void Main(string[] args)
        {
            int i = 5;
            // Unsafe method: uses address-of operator (&):
            unsafe
            {
                Foo(&i);
            }
            Console.WriteLine(i); // 7
        }
    }
}



