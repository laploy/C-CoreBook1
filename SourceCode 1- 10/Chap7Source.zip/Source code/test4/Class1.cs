﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test4
{
    class Class1
    {
        unsafe void Foo()
        {
            ////type* identifier;
            //void* identifier; //allowed but not recommended
            //int* p1, p2, p3;   // Ok
            ////int* p1, *p2, *p3;   // Invalid in C#
            //int* p; //  p is a pointer to an integer
            //int** p; // p is a pointer to a pointer to an integer.
            //int*[] p; //p is a single - dimensional array of pointers to integers.
            //char* p; //p is a pointer to a char.
            //void* p; // p is a pointer to an unknown type.

        }
    }
}
