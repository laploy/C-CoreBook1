//C#
int x = 5;
Console.WriteLine(x); 
int y = ++x;

// CIL แบบยังไม่ได้ออพติไมซ์
.locals init([0]int32 x, [1]int32 y)
ldc.i4.5
stloc.0
ldloc.0
call void [mscorlib]System.Console::WriteLine(int32)
ldloc.0
ldc.i4.1
add
stloc.0
ldloc.0
stloc.1 

// CIL ที่ออพติไมซ์ด้วยมือแล้ว
.locals init([0]int32, [1]int32)
ldc.i4.5
dup
call void [mscorlib]System.Console::WriteLine(int32)
ldc.i4.1
add
dup
stloc.0
stloc.1 


