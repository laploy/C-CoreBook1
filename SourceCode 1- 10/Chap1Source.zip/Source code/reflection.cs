// C# Reflection examples

// Using GetType to obtain type information:  
int i = 42;  
System.Type type = i.GetType();  
System.Console.WriteLine(type);  
//The Output is: System.Int32

// Using Reflection to get information from an Assembly:  
System.Reflection.Assembly info = typeof(System.Int32).Assembly;  
System.Console.WriteLine(info);  
//The output is: 
//mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089

// create instance of class DateTime
// normal way
DateTime dateTime = new DateTime();
// using Reflection
DateTime dateTime = (DateTime)Activator.CreateInstance(typeof(DateTime));