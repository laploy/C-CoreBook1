// C++ pointer as a func param
void f( MyClass * p ) {
    p->DoSomething();
}

int main() {
    MyClass c;
    f( & c );
}

//-----------------------------

// C# object as a func param
void f(MyClass p){
	p.DoSomething();
}

int main(){
	MyClass c = new MyClass();
	f(c);
}