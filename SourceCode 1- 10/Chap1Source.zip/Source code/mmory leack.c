int64 j = Int64::MaxValue; //2,147,483,647
List k[j];

void create_list(){
	// Create array of List object
	for(int64 i = 0; i < j; i++)
	{
		
		List k[i] = new List();
	}
	// do something with k	
}

void destroy_list(){
	for(int64 i = 0; i < j; i++)
	{
		delete k[i];
	}
}

int main() {
    // OK
    Queue p = new Queue;
    delete p; 

    // Memory leak
    Queue p = new Queue;
    // no delete
	
	create_list();
	// no destroy list
}

