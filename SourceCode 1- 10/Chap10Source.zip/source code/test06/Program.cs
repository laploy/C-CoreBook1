﻿using System;

namespace test06
{
    delegate bool D();
    delegate bool D2(int i);

    class Test
    {
        D del;
        D2 del2;
        public void TestMethod(int input)
        {
            int j = 0; 
            del = () => { j = 10; return j > input; };
            del2 = (x) => { return x == j; };  
            Console.WriteLine("j = {0}", j); // Invoke the delegate.  
            bool boolResult = del();
            Console.WriteLine("j = {0}. b = {1}", j, boolResult);
        }
        static void Main(string[] args)
        {
            Test test = new Test();
            test.TestMethod(5);
            bool result = test.del2(10);
            Console.WriteLine(result);
            Console.ReadKey();
        }
    }
}




