﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace test04
{
    class Customer: IEnumerable<T>
    {
        public string City { get; set; }
        public IEnumerator<T> GetEnumerator()
        {
            throw new NotImplementedException();
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
    class Program
    {
        public delegate TResult Func<TArg0, TResult>(TArg0 arg0);
        public static Customer customers = new Customer();
        static void Main(string[] args)
        {
            Func<int, bool> myFunc = x => x == 5;
            bool result = myFunc(4); // returns false of course

            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            int oddNumbers = numbers.Count(n => n % 2 == 1);

            var firstNumbersLessThan6 = numbers.TakeWhile(n => n < 6);

            var firstSmallNumbers = numbers.TakeWhile((n, index) => n >= index);

            customers.Where(c => c.City == "London");
        }
    }
}




