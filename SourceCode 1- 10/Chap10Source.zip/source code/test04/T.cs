﻿namespace test04
{
    internal class T
    {
        public string City { get; internal set; }
    }
}