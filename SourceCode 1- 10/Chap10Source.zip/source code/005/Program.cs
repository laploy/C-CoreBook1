﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _005
{
    class Program
    {
        public delegate bool del1(int i, float j); 

        static void Main(string[] args)
        {
            del1 myDel = (x, y) => x > y;
            bool result1 = myDel(2,3.2f);

            del1 myDel2 = (int a, float b) => a == b;
            bool result2 = myDel2(543, 1234.567f);
        }
    }
}




