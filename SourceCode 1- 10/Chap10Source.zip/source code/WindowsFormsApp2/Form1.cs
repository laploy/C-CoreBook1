﻿using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button1.Click += async (sender, e) =>
            {
                // ExampleMethodAsync returns a Task.  
                await ExampleMethodAsync();
                textBox1.Text += "\nControl returned to Click event handler.\n";
            };
        }

        async Task ExampleMethodAsync()
        {
            // The following line simulates a task-returning asynchronous process.  
            await Task.Delay(1000);
        }
    }
}


