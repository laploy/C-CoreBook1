﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private async Task button1_ClickAsync(object sender, EventArgs e)
        {
            // ExampleMethodAsync returns a Task.  
            await ExampleMethodAsync();
            textBox1.Text += "\r\nControl returned to Click event handler.\n";
        }
        async Task ExampleMethodAsync()
        {
            // The following line simulates a task-returning asynchronous process.  
            await Task.Delay(1000);
        }
    }
}


