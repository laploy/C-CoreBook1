﻿#define DEBUG  
//#define TRACE  
#undef TRACE 

using System;

namespace test
{
    class _0100example
    {
        static void Test()
        {
#if (DEBUG)
            Console.WriteLine("Debugging is enabled.");
#endif

#if (TRACE)
     Console.WriteLine("Tracing is enabled.");  
#endif
        }
    }
}


