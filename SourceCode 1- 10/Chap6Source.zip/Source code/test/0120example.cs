﻿//#define NET40
using System.Net.Http;

namespace test
{
    class _0120example
    {
        static void Main()
        {
#if NET40
        WebClient _client = new WebClient();
#else
            HttpClient _client = new HttpClient();
#endif
        }
    }
}


