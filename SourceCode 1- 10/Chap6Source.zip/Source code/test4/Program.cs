﻿using System;
using System.Threading;

namespace test4
{
    class Program
    {
        private static void loopTask(object value)
        {
            for (int x = 0; x < 10; x++)
            {
                Console.WriteLine("{0} x {1} = {2}", value, x, x* Convert.ToInt32(value));
                Thread.Sleep(100);
            }
        }
        static void Main(string[] args)
        {
            Thread myThread = new Thread(new ParameterizedThreadStart(loopTask));
            myThread.Start(12);
            Console.ReadKey();
        }
    }
}

