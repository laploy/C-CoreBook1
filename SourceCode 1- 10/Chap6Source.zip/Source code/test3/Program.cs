﻿using System;
using System.Threading;

namespace test3
{
    class Program
    {
        static void Main(string[] args)
        {
            new Thread(new ThreadStart(() => {
                for (int x = 0; x < 10; x++)
                {
                    Console.WriteLine("X => {0}", x);
                    Thread.Sleep(1000);
                }
            })).Start();
            for (int y = 0; y < 4; y++)
            {
                Console.WriteLine("Main thread.");
                Thread.Sleep(1500);
            }
            Console.ReadKey();
        }
    }
}
