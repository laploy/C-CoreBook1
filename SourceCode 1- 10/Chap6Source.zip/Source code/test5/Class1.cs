﻿using System.Linq;

namespace test5
{
    class Class1
    {
        void test()
        {
            var source = Enumerable.Range(1, 10000);
            var query = from item in source.AsParallel().WithDegreeOfParallelism(2)
                        where item % 2 == 0
                        select item;
        }
    }
}


