﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace test5
{
    class Class2
    {
        static void Main()
        {
            // The sum of these elements is 40.
            int[] input = { 4, 1, 6, 2, 9, 5, 10, 3 };
            int sum = 0;
            try
            {
                Parallel.ForEach(
                    input,                          // source collection
                    () => 0,                       // thread local initializer
                    (n, loopState, localSum) =>     // body
                    {
                            localSum += n;
                            Console.WriteLine("Thread={0}, n={1}, localSum={2}", 
                                Thread.CurrentThread.ManagedThreadId, n, localSum);
                            return localSum;
                        },
                        (localSum) => Interlocked.Add(ref sum, localSum) 
                    );
                Console.WriteLine("\nSum={0}", sum);
            }
            catch (AggregateException e)
            {
                Console.WriteLine("Parallel.ForEach has thrown an exception. " +
                    "THIS WAS NOT EXPECTED.\n{0}", e);
            }
        }
    }
}
