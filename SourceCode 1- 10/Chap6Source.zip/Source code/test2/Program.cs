﻿using System;
using System.Threading;

namespace test2
{
    class Program
    {
        private static void sampleTask()
        {
            for (int x = 0; x < 10; x++)
            {
                Console.WriteLine("X => {0}", x);
                Thread.Sleep(1000);
            }
        }
        static void Main(string[] args)
        {
            ThreadStart myDelegate = new ThreadStart(sampleTask);
            Thread myThread = new Thread(myDelegate);

            myThread.Start();

            for (int y = 0; y < 4; y++)
            {
                Console.WriteLine("Main thread.");
                Thread.Sleep(1000);
            }
            Console.ReadKey();
        }
    }
}
