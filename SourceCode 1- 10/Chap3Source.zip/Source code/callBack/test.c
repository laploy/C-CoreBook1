#include <stdio.h>

int(*Del)(int, int);

void show(int v)
{
	printf("%d\n", v);
}

int add(int a, int b)
{
	return a + b;
}

int delete(int a, int b)
{
	return a - b;
}

int main(void)
{
	Del = add;
	show((*Del)(13, 4));
	Del = delete;
	show((*Del)(13, 4));
	getc(stdin);
}


