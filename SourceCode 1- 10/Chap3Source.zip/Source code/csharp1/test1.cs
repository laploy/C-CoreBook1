﻿namespace csharp1
{
    public class foo
    {
        private int myVar;
        public int MyVar
        {
            get => myVar;
            set => myVar = value;
        }
    }

    public class bar
    {
        void fun()
        {
            foo ob = new foo();
            int i = ob.MyVar;
            ob.MyVar = 12;
        }
    }
}


