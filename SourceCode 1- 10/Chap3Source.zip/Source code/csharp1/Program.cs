﻿using System;

namespace csharp1
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("End.");
        }
    }
}
