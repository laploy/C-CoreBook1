#include <iostream>     // std::cout, std::ostream, std::ios
#include <fstream>      // std::filebuf
#include <string>


class foo
{
private:
	int myVar;
public:
	int getMyVar() {return myVar;}
	void setMyVar(int x) {myVar = x;}
};

class bar
{
	void fun()
	{
		foo ob;
		int i = ob.getMyVar();
		ob.setMyVar(12);
	}
};

int main(void)
{

}


