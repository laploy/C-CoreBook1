﻿namespace nestedClass
{

    public class List
    {
        private class Node
        {
            public int data;
            public Node next;
        }
        private Node head;
        private Node tail;

        public List()
        {
            head = new Node();
            tail = new Node();
        }
        public void Insert(int data)
        {
            Node n = new Node();
            n.data = data;
            n.next = null;
            if(head == null)
            {
                head = n;
                tail = n;
            }
            else
            {
                tail.next = n;
                tail = tail.next;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List myList = new List();
            myList.Insert(12);
            myList.Insert(34);
            myList.Insert(56);
        }
    }
}

