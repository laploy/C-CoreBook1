﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate1
{

    class Program
    {
        public delegate int Del(int a, int b);

        public static void Show(int v)
        {
            Console.WriteLine(v);
        }
        public static int Add(int a, int b)
        {
            return a + b;
        }
        public static int Delete(int a, int b)
        {
            return a - b;
        }
        static void Main(string[] args)
        {
            Del myDel = Add;
            Show(myDel(13,4));
            myDel = Delete;
            Show(myDel(13, 4));
        }
    }
}
