﻿using System.Windows.Forms;

namespace test02
{
    public partial class Form1 : Form
    {
        // Create a delegate.
        delegate void Del1();
        delegate void Del2(int x);

        // Instantiate the delegate using an anonymous method.
        Del2 d = delegate (int k) { /* ... */ };

        public Form1()
        {
            InitializeComponent();

            // Create a handler for a click event.
            button1.Click += delegate (System.Object o, System.EventArgs e)
            { System.Windows.Forms.MessageBox.Show("Click!"); };

            int n = 0;
            Del1 d = delegate () { System.Console.WriteLine("Copy #:{0}", ++n); };
        }

        void StartThread()
        {
            System.Threading.Thread t1 = new System.Threading.Thread
              (delegate ()
              {
                  System.Console.Write("Hello, ");
                  System.Console.WriteLine("World!");
              });
            t1.Start();
        }
    }
}


