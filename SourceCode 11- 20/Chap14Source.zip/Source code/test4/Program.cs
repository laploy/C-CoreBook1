﻿using System;

interface IPerson<T>
{
    void add(T book);
    void delete();
    T get();
}
class Employee<T> : IPerson<T>
{
    T enroll;
    public void add(T name)
    {
        this.enroll = name;
    }
    public void delete()
    {
        this.enroll = default(T);
    }
    public T get()
    {
        return this.enroll;
    }
}
class Program
{
    static void Main(string[] args)
    {
        Employee<string> myEmployee = new Employee<string>();
        myEmployee.add("Loy Vanich");
        Console.WriteLine(myEmployee.get());
    }
}

// output result
// Loy Vanich


