﻿

using System;

interface IVehicle
{
    void ChangeGear(int a);
    void SpeedUp(int a);
    void ApplyBrakes(int a);
}

class Bicycle : IVehicle
{
    int speed;
    int gear;

    public void ChangeGear(int newGear)
    {
        gear = newGear;
    }
    public void SpeedUp(int increment)
    {
        speed = speed + increment;
    }
    public void ApplyBrakes(int decrement)
    {
        speed = speed - decrement;
    }
    public void printStates()
    {
        Console.WriteLine("speed: " + speed + " gear: " + gear);
    }
}

class Bike : IVehicle
{
    int speed;
    int gear;

    public void ChangeGear(int newGear)
    {
        gear = newGear;
    }
    public void SpeedUp(int increment)
    {
        speed = speed + increment;
    }
    public void ApplyBrakes(int decrement)
    {
        speed = speed - decrement;
    }
    public void printStates()
    {
        Console.WriteLine("speed: " + speed +" gear: " + gear);
    }
}

class test
{
    public static void Main(String[] args)
    {
        Bicycle bicycle = new Bicycle();
        bicycle.ChangeGear(2);
        bicycle.SpeedUp(3);
        bicycle.ApplyBrakes(1);

        Console.WriteLine("Bicycle present state :");
        bicycle.printStates();

        Bike bike = new Bike();
        bike.ChangeGear(1);
        bike.SpeedUp(4);
        bike.ApplyBrakes(3);

        Console.WriteLine("Bike present state :");
        bike.printStates();
    }
}




