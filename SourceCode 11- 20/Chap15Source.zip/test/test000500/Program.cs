﻿using System;

namespace test000500
{
    interface IDeveloper
    {
        void LearnNewLanguage(string language)
        {
            Console.Write($"Learning {language} in a default way.");
        }
    }
    interface IBackendDev : IDeveloper
    {
        void LearnNewLanguage(string language)
        {
            Console.Write($"Learning {language} in a backend way.");
        }
    }
    interface IFrontendDev : IDeveloper
    {
        void LearnNewLanguage(string language)
        {
            Console.Write($"Learning {language} in a frontend way.");
        }
    }
    interface IFullStackDev : IBackendDev, IFrontendDev { }                                                             
    class Dev : IFullStackDev { }
    class Program
    {
        static void Main(string[] args)
        {
            IFullStackDev dev = new Dev();
            dev.LearnNewLanguage("TypeScript");
        }
    }
}

