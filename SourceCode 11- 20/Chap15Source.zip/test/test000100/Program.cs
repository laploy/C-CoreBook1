﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test000100
{
    interface IDeveloper
    {
        void LearnNewLanguage(string language, DateTime dueDate);
    }

    class BackendDev : IDeveloper
    {
        public void LearnNewLanguage(string language, DateTime dueDate)
        {
            // Learning new language...
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}


