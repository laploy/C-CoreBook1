﻿using System;

namespace test000600
{
    public interface IRight
    {
        public void RightLog(string s);
    }
    public interface ILeft
    {
        public void LeftLog(string s);
    }
    public interface IBody : IRight, ILeft
    {
        public void BodyLog(string s);
    }
    public class Robot : IBody
    {
        public void RightLog(string s)
        {
            Console.WriteLine("Right " + s);
        }
        public void LeftLog(string s)
        {
            Console.WriteLine("Left " + s);
        }
        public void BodyLog(string s)
        {
            Console.WriteLine("Body " + s);
        }
        public void RobotLog(string s)
        {
            Console.WriteLine("Robot " + s);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Robot myRobot = new Robot();
            myRobot.RightLog("book");
            myRobot.LeftLog("house");
            myRobot.BodyLog("duck");
            myRobot.RobotLog("cat");

            IBody myAndroi = new Robot();
            myAndroi.RightLog("test1");
            myAndroi.LeftLog("test1");
            myAndroi.BodyLog("test1");
            myAndroi.RobotLog("test1");
        }
    }
}

