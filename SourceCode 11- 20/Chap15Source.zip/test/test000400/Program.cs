﻿using System;

namespace test000400
{
    interface IDeveloper
    {
        void LearnNewLanguage(string language, DateTime dueDate);
        void LearnNewLanguage(string language)
        {
            // default implementation
            LearnNewLanguage(language, DateTime.Now.AddMonths(6));
        }
    }

    class BackendDev : IDeveloper // compiles OK
    {
        public void LearnNewLanguage(string language, DateTime dueDate)
        {
            // Learning new language...
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IDeveloper dev = new BackendDev();
            dev.LearnNewLanguage("Rust"); 
        }
    }
}


