﻿using System;

namespace test000300
{
    interface IDeveloper
    {
        void LearnNewLanguage(string language, DateTime dueDate);
        void LearnNewLanguage(string language)
        {
            // default implementation
            LearnNewLanguage(language, DateTime.Now.AddMonths(6));
        }
    }

    class BackendDev : IDeveloper
    {
        public void LearnNewLanguage(string language, DateTime dueDate)
        {
            // Learning new language...
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}


