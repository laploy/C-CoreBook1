﻿using System;

namespace test000200
{
    interface IDeveloper
    {
        void LearnNewLanguage(string language, DateTime dueDate);
        void LearnNewLanguage(string language); // new method added
    }

    class BackendDev : IDeveloper
    {
        public void LearnNewLanguage(string language, DateTime dueDate)
        {
            // Learning new language...
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}



