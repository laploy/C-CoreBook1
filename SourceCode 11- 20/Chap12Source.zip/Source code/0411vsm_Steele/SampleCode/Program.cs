﻿using System;
using System.Linq.Expressions;

namespace SampleCode
{
	class Program
	{
		static void Main(string[] args)
		{
			Example1();
			Example2();
			Example3();
		}

		/// <summary>
		/// Using standardized validation techniques
		/// </summary>
		private static void Example3()
		{
			var d1 = new DummyClass(null, null);
		}

		/// <summary>
		/// Compiling and executing an expression tree
		/// </summary>
		private static void Example2()
		{
			Expression<Func<int, bool>> isEvenExpression = i => i % 2 == 0;
			Func<int, bool> isEven = isEvenExpression.Compile();
			for (var a = 0; a <= 10; a++)
			{
				Console.WriteLine("Is {0} even? {1}", a, isEven(a));
			}
		}

		/// <summary>
		/// Simple example showing a lambda, and then the same lambda as an expression tree
		/// </summary>
		private static void Example1()
		{
			Func<string, string, string> combine = (a, b) => a.ToLower() + b.ToUpper();
			var one = "One";
			var two = "Two";
			var combined = combine(one, two);

			Expression<Func<string, string, string>> tree = (a, b) => a.ToLower() + b.ToUpper();

			Console.WriteLine("Paramter Count: {0}", tree.Parameters.Count);
			foreach (var param in tree.Parameters)
			{
				Console.WriteLine("\tParameter Name: {0}", param.Name);
			}

			var body = (BinaryExpression)tree.Body;
			Console.WriteLine("Binary Expression Type: {0}", body.NodeType);
			Console.WriteLine("Method to be called: {0}", body.Method);
			Console.WriteLine("Return Type: {0}", tree.ReturnType);
		}
	}
}
