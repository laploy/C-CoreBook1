﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SampleCode
{
	class DummyClass
	{
		public DummyClass(string filename, DummyClass parent)
		{
			Validator.ThrowIfNullOrEmpty(() => filename);
			Validator.ThrowIfNull(() => parent);
		}
	}
}
