﻿using System;

namespace test
{
    internal class Class1
    {
        internal object AddItem(object mItem)
        {
            return this;
        }
    }
}