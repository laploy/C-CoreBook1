﻿using System;
using System.Collections.Generic;
using System.Text;

namespace test
{
    class Program
    {
        private static object mItem3;
        private static object mItem2;
        private static object mItem;

        static void Main(string[] args)
        {
            Class1 myObject = new Class1();
            myObject.AddItem(mItem).AddItem(mItem2).AddItem(mItem3);
        }
    }
}
