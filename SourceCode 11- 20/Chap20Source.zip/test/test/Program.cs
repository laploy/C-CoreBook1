﻿using System.Threading.Tasks;
using static System.Console;

namespace test
{
    class Program
    {
        static async Task Main(string[] args)
        {
            WriteLine($"Hello {System.DateTime.Now}");
            await Task.Delay(2000);
            WriteLine($"Hello {System.DateTime.Now}");
        }
    }
}


