﻿using System;

namespace test6
{
    interface IDimensions
    {
        float getLength();
        float getWidth();
    }

    class Box : IDimensions
    {
        float lengthInches;
        float widthInches;

        public Box(float length, float width)
        {
            lengthInches = length;
            widthInches = width;
        }
        float IDimensions.getLength()
        {
            return lengthInches;
        }
        float IDimensions.getWidth()
        {
            return widthInches;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Box box1 = new Box(30.0f, 20.0f);
            IDimensions dimensions = box1;
            Console.WriteLine("Length: {0}", dimensions.getLength());
            Console.WriteLine("Width: {0}", dimensions.getWidth());
        }
    }
}
/* Output:
    Length: 30
    Width: 20
*/
