﻿using System;

namespace test2
{
    public interface ILog
    {
        void WriteLog();
    }
    public class Test1 : ILog
    {
        public void WriteLog()
        {
            Console.WriteLine("Test1 was Logged");
        }
    }
    public class Test2 : ILog
    {
        public void WriteLog()
        {
            Console.WriteLine("Test2 was Logged");
            Console.WriteLine("And Logged it different, than Test1");
        }
    }
    public class LogClass
    {
        public static void WriteLog(ILog logObject)
        {
            logObject.WriteLog();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Test1 myTest1 = new Test1();
            Test2 myTest2 = new Test2();

            LogClass.WriteLog(myTest1);
            LogClass.WriteLog(myTest2);
            /*
                Test1 was Logged
                Test2 was Logged
                And Logged it different, than Test1
            */
        }
    }
}


