﻿using System;

namespace test
{
    public interface ILog
    {
        //I want to have a especific method that I'll use in MyLogClass
        void WriteLog();
    }
    public class Test1 : ILog
    {
        public void WriteLog()
        {
            Console.Write("MyClass was Logged");
        }
    }
    public class Test2 : ILog
    {
        public void WriteLog()
        {
            Console.Write("MyOtherClass was Logged");
            Console.Write("And I Logged it different, than MyClass");
        }
    }
    public class LogClass
    {
        public static void WriteLog(ILog logObject)
        {
            logObject.WriteLog(); //So I can use WriteLog here.
        }
    }
    public class MyMainClass
    {
        public void DoSomething()
        {
            Test1 myTest1 = new Test1();
            Test2 myTest2 = new Test2();

            LogClass.WriteLog(myTest1);
            LogClass.WriteLog(myTest2);
        }
    }
}

